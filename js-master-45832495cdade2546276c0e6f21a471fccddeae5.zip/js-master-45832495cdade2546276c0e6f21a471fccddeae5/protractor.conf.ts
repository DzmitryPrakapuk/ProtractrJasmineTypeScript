import {browser, Config} from "protractor";
import {initializeReporters} from "./helper/reporters";

export let config: Config = {
    directConnect: true,
    shardTestFiles: false,
    maxInstances: 3,
    capabilities: {
        browserName: 'chrome',
    },
    seleniumAddress: 'http://127.0.0.1:4444/wd/hub',

    specs: [
        './test/*.e2e.spec.js',
    ],

    exclude: [ ],

    suites:{
    },


    params: {
        baseUrl: 'https://www.google.by/',
        waitWebElementMaxTimeout: 30000,
        takeScreenShotFromEachAllureStep: false,
    },


    onPrepare: async () => {
        browser.manage().window().maximize();
        await initializeReporters();
    },

    jasmineNodeOpts: {
        defaultTimeoutInterval: 70000,
    }
};