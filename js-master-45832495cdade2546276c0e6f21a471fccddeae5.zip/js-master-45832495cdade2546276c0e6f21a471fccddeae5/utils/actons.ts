import {browser, ElementFinder} from 'protractor';

export class Actions {

    public static async click(elemment: ElementFinder) {
        await browser.actions().click(elemment).perform();
    };

    public static async doubleClick(elemment: ElementFinder) {
        await browser.actions().doubleClick(elemment).perform();
    };

    public static async dragAndDrop(elemment: ElementFinder, target:ElementFinder) {
        await browser.actions().dragAndDrop(elemment, target).perform();
    };

    public static async hoverOnElement(element: ElementFinder) {
        await browser.actions().mouseMove(element).perform();
    };

    public static async mouseMoveByCoordinates(xValue: number, yValue: number) {
        await browser.actions().mouseMove({x: xValue, y: yValue}).perform();
    };

    public static async sendKeys(element: ElementFinder, value:string) {
        await element.click();
        await browser.actions().sendKeys(value).perform();
    };


}