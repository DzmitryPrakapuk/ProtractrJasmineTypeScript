import {browser, element, by} from "protractor";
import {Actions} from "../utils/actons";

describe('Google', async() => {

    it('go to google search page', async() => {
        await browser.waitForAngularEnabled(false);
        await browser.get('http://the-internet.herokuapp.com/drag_and_drop');
    });
});