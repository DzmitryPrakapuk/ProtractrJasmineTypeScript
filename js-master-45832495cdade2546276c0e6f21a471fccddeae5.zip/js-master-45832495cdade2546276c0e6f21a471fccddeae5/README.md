E2e test definition
------------------

* tests end user experience
* tests component integration (i.e. integration testing is submerged into e2e tests)
* run by protractor runner
* written with jasmine test framework


### Requirements
 * `Node` version >= 8.9
 * `Java` verion >= 8


Running tests
-------------

1. Clone

2. Run 'npm i'

3. To run all tests run 'npm run protractorWithServer'


Architecture:
controls - ability to work with base control like buttons, links, inputs. For example button - returnByValue, clickBy Value
helper - waiters and allure report are here
utils - for now actions lib is just here 