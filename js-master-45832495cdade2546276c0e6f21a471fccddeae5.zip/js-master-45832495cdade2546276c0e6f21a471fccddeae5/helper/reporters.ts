import {SpecReporter} from "jasmine-spec-reporter";
const specReporter = new SpecReporter();


export function initializeReporters() {

    jasmine.getEnv().addReporter(specReporter);

    const jasmine2HtmlReporter = require('protractor-jasmine2-html-reporter');
    jasmine.getEnv().addReporter(
        new jasmine2HtmlReporter({
            savePath: './output/jasmineHtmlReport/',
            takeScreenshots: true,
            takeScreenshotsOnlyOnFailures: true,
            fixedScreenshotName: true,
        })
    );

    const allureReporter = require('jasmine-allure-reporter');
    jasmine.getEnv().addReporter(new allureReporter({
        resultsDir: './output/allure-results',
    }) as any);
}
