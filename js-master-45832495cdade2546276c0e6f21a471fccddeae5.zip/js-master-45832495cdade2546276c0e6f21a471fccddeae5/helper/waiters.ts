import {browser, ElementFinder, ExpectedConditions} from "protractor";

export class Waiters {

    public static async waitUntilElementIsDisplayed (webElement:ElementFinder) {
       try {
        await browser.wait(ExpectedConditions.visibilityOf(webElement),
            browser.params.waitWebElementMaxTimeout );
       }
       catch (err) {
           if(err.name === 'TimeoutError') {
               throw `Element is not found, waiting time is over`
           }
           else {
               throw err.name
           }
       }
    };

    public static async waitUntilElementNotDisplayed (webElement:ElementFinder) {
        try{
            await browser.wait(ExpectedConditions.invisibilityOf(webElement),
                browser.params.waitWebElementMaxTimeout );
        }
        catch (err) {
            if(err.name === 'TimeoutError') {
                throw `Element is still present, waiting time is over`
            }
            else {
                throw err.name
            }
        }

    };

    public static async waitUntilElementIsClickable (webElement:ElementFinder,placeAndWaitElement:string='') {
        try{
            await browser.wait(ExpectedConditions.elementToBeClickable(webElement),
                browser.params.waitWebElementMaxTimeout );
        }
        catch (err) {
            if(err.name === 'TimeoutError') {
                throw `Element is not clickable, waiting time is over`
            }
            else {
                throw err.name
            }
        }
    };

    public static async waitUntilUrlIsContained(url:string) {
        await browser.wait(ExpectedConditions.urlContains(url),
            browser.params.waitWebElementMaxTimeout );
    };
}