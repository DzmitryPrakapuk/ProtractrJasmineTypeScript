import {allureStep} from "../helper/allure/allureSteps";

export class RadioButton{

    public static returnByValue(value: string) {

    }

    public static async checkByValue(value:string) {
        await allureStep(`Check radio button by value '${value}'`, async () => {

        })
    };

}