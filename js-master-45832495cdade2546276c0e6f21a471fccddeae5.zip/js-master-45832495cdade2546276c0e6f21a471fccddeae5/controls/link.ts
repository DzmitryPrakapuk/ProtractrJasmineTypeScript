import {allureStep} from "../helper/allure/allureSteps";
import {Waiters as w} from "../helper/waiters";
import {ElementFinder} from "protractor";

export class Link {

    //need implementation
    public static returnByValue(buttonValue:string):ElementFinder {
        return
    };

    public static async clickByName(linkName:string, waitElem: any) {
        await allureStep(`Click on the link by '${linkName}' name`, async () => {

        });
    }

}