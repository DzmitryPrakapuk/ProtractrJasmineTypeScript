import {allureStep} from "../helper/allure/allureSteps";


export class Textarea{

    public static async enterValueInTextarea(textarea:any, text: string) {
        await allureStep(`Fill field with '${text}' value`, async() => {
            await textarea.clear();
            await textarea.sendKeys(text);
        });
    };

}