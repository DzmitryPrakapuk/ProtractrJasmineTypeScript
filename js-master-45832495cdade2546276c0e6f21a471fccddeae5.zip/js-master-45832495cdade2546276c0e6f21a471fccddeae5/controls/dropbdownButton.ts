import {allureStep} from "../helper/allure/allureSteps";
import {ElementFinder} from "protractor";

export class DropbdownButton{

    public static returnDropDown():ElementFinder {
        return
    };

    public static async clickOnOptionFromDropdown(buttonText: string, dropdownOptionText: string) {
        await allureStep(`Click on the dropdown '${buttonText}' and select option '${dropdownOptionText}'`,
            async () => {
        })
    };


}