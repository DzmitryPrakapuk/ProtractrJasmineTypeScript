import {ElementFinder} from "protractor";

export abstract class Button {

    //need implementation
    public static returnByValue(buttonValue:string): ElementFinder{
        return
    };


    public static async clickByValue(buttonValue: string, waitElement:any) {};

}