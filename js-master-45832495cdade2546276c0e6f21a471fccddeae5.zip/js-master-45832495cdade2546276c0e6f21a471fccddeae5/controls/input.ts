import {allureStep} from "../helper/allure/allureSteps";

export class Input{

    public static async enterValueInInputField(input:any, text: string) {
        await allureStep(`Fill field with '${text}' value`, async() => {
            await input.clear();
            await input.sendKeys(text);
        });
    };
}