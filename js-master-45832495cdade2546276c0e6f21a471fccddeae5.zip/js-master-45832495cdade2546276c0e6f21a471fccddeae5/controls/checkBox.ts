import {allureStep} from "../helper/allure/allureSteps";
import {ElementFinder} from "protractor";

export class CheckBox{


    public static returnByValue(value: string):ElementFinder {
        return
    }

    public static async checkByValue(value:string) {
        await allureStep(`Check ckeckbox by value '${value}'`, async () => {
        })
    };

}